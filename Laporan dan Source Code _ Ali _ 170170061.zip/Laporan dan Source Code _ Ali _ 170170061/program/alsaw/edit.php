<?php
include_once ('header.php');
?>

<div class="input-wrapper">
  <div class="container">
    <div class="heading">
      <h1> Edit Data Siswa </h1>

	<?php
		$nis = $_GET['nis'];
		$tampil = mysqli_query($koneksi,"SELECT * FROM siswa, matrikulasi WHERE matrikulasi.nis=siswa.nis and matrikulasi.nis='$nis'");
		while ($data = mysqli_fetch_array($tampil)) {
			?>

      <form action="update.php" method="POST">
        <div class="row">
          <div class="col-25">
            <label>Nama</label>
          </div>
          <div class="col-75">
            <input type="text" name="nama" value="<?php echo $data['nama']; ?>">
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>NIS</label>
          </div>
          <div class="col-75">
            <input type="text"  name="nis" value="<?php echo $data['nis']; ?>">
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label for="country">Kelas</label>
          </div>
          <div class="col-75">
            <select id="kelas" name="kelas">
              <option <?php if($data['kelas']=="VII"){echo "Selected='selected'";} ?> value="VII">VII</option>
              <option <?php if($data['kelas']=="VIII"){echo "Selected='selected'";} ?> value="VIII">VIII</option>
              <option <?php if($data['kelas']=="IX"){echo "Selected='selected'";} ?> value="IX">IX</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>Jenis Beasiswa</label>
          </div>
          <div class="col-75">
            <select id="jb" name="jenis_beasiswa">
              <option value="bkm" selected="select">Beasiswa Kurang Mampu</option>
              <option value="bp" hidden>Beasiswa Prestasi</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>Kartu Asuransi Miskin</label>
          </div>
          <div class="col-75">
            <select id="c1" name="c1">
              <option <?php if($data['c1']=="5"){echo "Selected='selected'";} ?> value="5">Ada</option>
              <option <?php if($data['c1']=="1"){echo "Selected='selected'";} ?> value="1">Tidak Ada</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>Surat Keterangan Tidak Mampu</label>
          </div>
          <div class="col-75">
            <select id="c2" name="c2">
              <option <?php if($data['c2']=="5"){echo "Selected='selected'";} ?> value="5">Ada</option>
              <option <?php if($data['c2']=="1"){echo "Selected='selected'";} ?> value="1">Tidak Ada</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>Status Anak dalam Keluarga</label>
          </div>
          <div class="col-75">
            <select id="c3" name="c3">
              <option <?php if($data['c3']=="5"){echo "Selected='selected'";} ?> value="5">Orang Tua Lengkap</option>
              <option <?php if($data['c3']=="3"){echo "Selected='selected'";} ?> value="3">Yatim / Piatu</option>
              <option <?php if($data['c3']=="2"){echo "Selected='selected'";} ?> value="2">Yatim Piatu</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>Jumlah Penghasilan Orang Tua</label>
          </div>
          <div class="col-75">
            <select id="c4" name="c4">
              <option <?php if($data['c4']=="2"){echo "Selected='selected'";} ?> value="2"> &lt;1.000.000 </option>
              <option <?php if($data['c4']=="3"){echo "Selected='selected'";} ?> value="3">1.000.000 – 2.000.0000</option>
              <option <?php if($data['c4']=="4"){echo "Selected='selected'";} ?> value="4">2.000.000 – 3.000.000</option>
              <option <?php if($data['c4']=="5"){echo "Selected='selected'";} ?> value="5">&gt;3.000.000</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>Jumlah Tanggungan Orang Tua</label>
          </div>
          <div class="col-75">
            <select id="c5" name="c5">
              <option <?php if($data['c5']=="1"){echo "Selected='selected'";} ?> value="1">1 Orang</option>
              <option <?php if($data['c5']=="2"){echo "Selected='selected'";} ?> value="2">2 Orang</option>
              <option <?php if($data['c5']=="3"){echo "Selected='selected'";} ?> value="3">3 Orang</option>
              <option <?php if($data['c5']=="4"){echo "Selected='selected'";} ?> value="4">4 Orang</option>
              <option <?php if($data['c5']=="5"){echo "Selected='selected'";} ?> value="5">&gt;=5 Orang</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>Rata - Rata Nilai Rapor Semester Terakhir</label>
          </div>
          <div class="col-75">
            <select id="c6" name="c6">
              <option <?php if($data['c6']=="1"){echo "Selected='selected'";} ?> value="1">51-60</option>
              <option <?php if($data['c6']=="2"){echo "Selected='selected'";} ?> value="2">61-70</option>
              <option <?php if($data['c6']=="3"){echo "Selected='selected'";} ?> value="3">71-80</option>
              <option <?php if($data['c6']=="4"){echo "Selected='selected'";} ?> value="4">81-90</option>
              <option <?php if($data['c6']=="5"){echo "Selected='selected'";} ?> value="5">91-100</option>
            </select>
          </div>
        </div>        
        <div class="row">
          <input type="submit" name="update" class="sub-data" value="Update">
        </div>
      </form>
<?php } ?>
    </div>
  </div>
  
</div>


<?php
include_once ('footer.php');
?>