<?php

if(isset($_POST['submit'])){
	
	include_once ('koneksi.php');

	$nama=$_POST['nama'];
	$nis=$_POST['nis'];
	$kelas=$_POST['kelas'];
	$jb=$_POST['jenis_beasiswa'];
	$c1=$_POST['c1'];
	$c2=$_POST['c2'];
	$c3=$_POST['c3'];
	$c4=$_POST['c4'];
	$c5=$_POST['c5'];
	$c6=$_POST['c6'];

	$query = mysqli_query($koneksi,"SELECT * FROM siswa WHERE nis='$nis'");

	if (empty($nama) || empty($nis) || empty($kelas) || empty($jb) || empty($c1) || empty($c2) || empty($c3) || empty($c4) || empty($c5) || empty($c6)) {

		echo "<script>alert('gagal di tambahkan');</script>";
		header("location: input-data.php?notif=gagal");

	}elseif(mysqli_num_rows($query)){
		header("location:input-data.php?&notif=sama");
	}else{

		$input = mysqli_query($koneksi,"INSERT INTO siswa VALUES('$nis', '$nama', '$kelas')");

		$input2 = mysqli_query($koneksi,"INSERT INTO matrikulasi VALUES(NULL, '$nis','$c1','$c2','$c3','$c4','$c5','$c6')");

		echo "<script>alert('berhasil di input');</script>";
		header("location: lihat-data.php");	
		
	}





}

?>