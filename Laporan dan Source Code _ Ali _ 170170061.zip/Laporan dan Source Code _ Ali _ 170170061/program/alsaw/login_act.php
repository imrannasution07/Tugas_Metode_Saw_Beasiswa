<?php

	include_once ('koneksi.php');

	$username = $_POST['username'];
	$password = $_POST['password'];

	$login = mysqli_query($koneksi,"SELECT * FROM admin WHERE username='$username' AND password='$password'");

	if (mysqli_num_rows($login) == 0){
		header("location: login.php");
	}else{
		$row = mysqli_fetch_assoc($login);
		
		session_start();

		$_SESSION['id'] = $row['id'];
		$_SESSION['username'] = $row['username'];

		header("location: index.php");
	}

?>	