<?php
include_once ('header.php');
?>
	
<div class="table-wrapper">
	<div class="container">
		<div class="heading">
		<h1> Tabel Matriks Keputusan </h1>

		<table>
		<thead>
		<tr>
			<th>No.</th>
			<th>NIS</th>
			<th>Nama</th>
			<th>Kelas</th>
			<th>C1</th>
			<th>C2</th>
			<th>C3</th>
			<th>C4</th>
			<th>C5</th>
			<th>C6</th>
			<th>Operasi</th>
		</tr>
		</thead>
		<tbody>
		<?php

		$query = mysqli_query($koneksi,"SELECT * FROM siswa, matrikulasi WHERE matrikulasi.nis=siswa.nis ORDER BY matrikulasi.nis ASC");
		
		if(mysqli_num_rows($query) == 0){			echo '<tr><td colspan="7">Tidak ada data!</td></tr>';
		}else{	
			$no = 1;
			while($data = mysqli_fetch_array($query)){
				?>
				<tr>
				<td><?php echo $no++; ?></td>
				<td><?php echo $data['nis']; ?></td>
				<td><?php echo $data['nama']; ?></td>
				<td><?php echo $data['kelas']; ?></td>
				<td><?php echo $data['c1']; ?></td>
				<td><?php echo $data['c2']; ?></td>
				<td><?php echo $data['c3']; ?></td>
				<td><?php echo $data['c4']; ?></td>
				<td><?php echo $data['c5']; ?></td>
				<td><?php echo $data['c6']; ?></td>
				<td>
					<a href="edit.php?nis=<?php echo $data["nis"]; ?>" class="btn facebook" onclick="return confirm('Ubah Data?')">Edit</a> 
					<a href="hapus.php?nis=<?php echo $data["nis"]; ?>" class="btn pinterest" onclick="return confirm('Hapus Data?')">Hapus</a> 
				</td>
				</tr>
</tbody>



		<?php
			}
			
		}
		?>
	</table>



		</div>	
	</div>
</div>

<?php
include_once ('footer.php');
?>