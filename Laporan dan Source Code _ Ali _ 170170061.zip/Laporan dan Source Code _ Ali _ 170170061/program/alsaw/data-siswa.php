<?php
include_once ('header.php');
?>
	
<div class="table-wrapper">
	<div class="container">
		<div class="heading">
		<h1> Data Siswa </h1>
		<table>
		<thead>
		<tr>
			<th>No.</th>
			<th>NIS</th>
			<th>Nama</th>
			<th>Kelas</th>
			<th>Kartu Asuransi Miskin</th>
			<th>Surat Keterangan Tidak Mampu</th>
			<th>Status Anak dalam Keluarga</th>
			<th>Jumlah Penghasilan Orang Tua</th>
			<th>Jumlah Tanggungan Orang Tua</th>
			<th>Rata - Rata Nilai Rapor Semester Terakhir</th>
		</tr>
		</thead>
		<tbody>
		<?php

		$query = mysqli_query($koneksi,"SELECT * FROM siswa, matrikulasi WHERE matrikulasi.nis=siswa.nis ORDER BY matrikulasi.nis ASC");
		
		if(mysqli_num_rows($query) == 0){			echo '<tr><td colspan="7">Tidak ada data!</td></tr>';
		}else{	
			$no = 1;
			while($data = mysqli_fetch_array($query)){
				?>
				<tr>
				<td><?php echo $no++; ?></td>
				<td><?php echo $data['nis']; ?></td>
				<td><?php echo $data['nama']; ?></td>
				<td><?php echo $data['kelas']; ?></td>
				<td><?php 
				if ($data['c1'] == 5) {
				 	echo "Ada";
				 }else{
				 	echo "Tidak Ada";
				 } ?></td>
				<td><?php 
				if ($data['c2'] == 5) {
				 	echo "Ada";
				 }else{
				 	echo "Tidak Ada";
				 } ?></td>
				<td><?php 
				if ($data['c3'] == 5) {
				 	echo "Orang Tua Lengkap";
				 }else if($data['c3'] == 3){
				 	echo "Yatim / Piatu";
				 }else{
				 	echo "Yatim piatu";
				 } ?></td>
				<td><?php 
				if ($data['c4'] == 5) {
				 	echo "> 3.000.000";
				 }else if($data['c4'] == 4){
				 	echo "2.000.000 – 3.000.000";
				 }else if($data['c4'] == 3){
				 	echo "1.000.000 – 2.000.0000";
				 }else{
				 	echo "< 1.000.000";
				 } ?></td>
				<td><?php 
				if ($data['c5'] == 5) {
				 	echo ">= 5 Orang";
				 }else if($data['c5'] == 4){
				 	echo "4 Orang";
				 }else if($data['c5'] == 3){
				 	echo "3 Orang";
				 }else if($data['c5'] == 2){
				 	echo "2 Orang";
				 }else{
				 	echo "1 Orang";
				 } ?></td>
				<td><?php 
				if ($data['c6'] == 5) {
				 	echo "91-100";
				 }else if($data['c6'] == 4){
				 	echo "81-80";
				 }else if($data['c6'] == 3){
				 	echo "71-80";
				 }else if($data['c6'] == 2){
				 	echo "61-70";
				 }else{
				 	echo "51-60";
				 } ?></td>
				</2r>
</tbody>



		<?php
			}
			
		}
		?>
	</table>



		</div>	
	</div>
</div>

<?php
include_once ('footer.php');
?>