<?php
include_once ('header.php');

			$bobot = array(5,4,5,3,3,1); //nilai bobot per kriteriaa

		//cari min dan max
			$findMax = mysqli_query($koneksi,"SELECT 
				max(c1) as maxC1, 
				max(c2) as maxC2,
				max(c5) as maxC5,
				max(c6) as maxC6
				FROM matrikulasi");
			$max = mysqli_fetch_array($findMax);

			$findMin = mysqli_query($koneksi,"SELECT
				min(c3) as minC3,
				min(c4) as minC4
				FROM matrikulasi");
			$min = mysqli_fetch_array($findMin);			

		//fungsi tampil nama
			function getName($id){

				$koneksi = mysqli_connect("localhost","root","","apk_saw") or die("Koneksi ke database gagal!");
				$q =mysqli_query($koneksi,"SELECT * FROM siswa where nis = '$id'");
				$d = mysqli_fetch_array($q);
				return $d['nama'];
			}

			$ambilData = mysqli_query($koneksi,"SELECT * FROM matrikulasi");

			?>

			<div class="table-wrapper">
				<div class="container">
					<div class="heading">
						<h1>Tabel Perangkingan</h1>
						<a href="cetak.php" target="_link" class="btn twitter header-right print">Cetak</a>
	<table id="rangking">
		<thead>
		<tr>
			<th>No</th>
			<th>Nama</th>
			<th>Nilai Preferensi</th>
		</tr>
		</thead>
		
		<?php
		
		//menghitung nilai preferensi
		$rank = array();
		$names = array();
		while ($dt3 = mysqli_fetch_array($ambilData)) {
		
		$preferensi = round(
			(($dt3['c1']/$max['maxC1'])*$bobot[0])+
			(($dt3['c2']/$max['maxC2'])*$bobot[1])+
			(($min['minC3'])/$dt3['c3']*$bobot[2])+
			(($min['minC4'])/$dt3['c4']*$bobot[3])+
			(($dt3['c5']/$max['maxC5'])*$bobot[4])+
			(($dt3['c6']/$max['maxC6'])*$bobot[5])
			,3);

		$rank[$dt3['nis']] = $preferensi;
		$names[$dt3['nis']]=$dt3['nis'];
			}

		$no=1;
		arsort($rank);
		foreach($rank as $ranks => $preferensi){
			
			?>
			<tr>
				<td><?php echo $no++; ?></td>
				<td><?php echo getName($names[$ranks]); ?></td>
				<td><?php echo $preferensi; ?></td>
			</tr>
			
	<?php	}  ?>

	
		</table>



						</div>
					</div>
				</div>
			

				<?php

				include_once ('footer.php');
				?>