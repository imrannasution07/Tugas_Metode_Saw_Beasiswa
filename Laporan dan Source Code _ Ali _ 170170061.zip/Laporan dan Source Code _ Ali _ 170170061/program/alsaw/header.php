<?
include_once ("koneksi.php");

session_start();
  $id = isset($_SESSION['id']) ? $_SESSION['id'] : false;
  $user = isset($_SESSION['username']) ? $_SESSION['username'] : false;
?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPK Metode SAW - Beasiswa</title>
    <link rel="stylesheet" href="stylesheet.css">
  </head>
  <body>
    <header>
      <div class="container">
        <div class="header-left">
          <div class="logo"><a href="index.php" style="color: white;">Sistem Penentuan Beasiswa</a></div>
        </div>
        
        <?php if ($id) { ?>
        <div class="header-right">
          <a href="input-data.php">Input Data</a>
          <a href="data-siswa.php">Data Siswa</a>
          <a href="lihat-data.php">Lihat Data</a>
          <a href="normalisasi.php">Normalisasi</a>
          <a href="preferensi.php">Preferensi</a>
          <a href="perangkingan.php">Perangkingan</a>
          <a href="logout.php">Logout</a>
        </div>  
        <?php } ?>

      </div>
    </header>