<?php
include_once ('header.php');

if ($id == 0) {
	header("location: login.php");
}

?>

    <div class="message-wrapper">
      <div class="container">
        <div class="heading">
          <h2>Selamat Datang di Sistem Pendukung Keputusan<br>
Penentuan Penerima Beasiswa di SMP X<br>
Menggunakan Metode Simple Additive Weighting (SAW)</h2>
        </div>
      </div>
    </div>

<?php
include_once ('footer.php');
?>