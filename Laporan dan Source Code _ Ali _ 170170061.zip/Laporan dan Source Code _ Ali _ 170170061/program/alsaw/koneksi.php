<?php

$koneksi = mysqli_connect("localhost","root","","apk_saw") or die("koneksi ke database gagal");

?>