<?php
include_once ('header.php');
  if($id){
    header("location: index.php");
  }

?>

<div class="input-wrapper">
  <div class="container">
    <div class="heading">
      <h1> Login Admin </h1>

      <form action="login_act.php" method="POST">
        <div class="row">
          <div class="col-md">
            <input type="text" name="username" placeholder="Username">
          </div>
        </div>
        <div class="row">
          <div class="col-md">
            <input type="password" name="password" placeholder="Password">
          </div>
          </div>
        <div class="row" style="text-align: center;">
          <input type="submit" name="login" class="login" value="Login">
        </div>        
      </form>

    </div>
  </div>
  
</div>


<?php
include_once ('footer.php');
?>