<?php 

	include_once ('koneksi.php');
	$nis = $_GET['nis'];
	mysqli_query($koneksi,"DELETE FROM matrikulasi WHERE nis='$nis'");

	header("location: lihat-data.php");

?>
