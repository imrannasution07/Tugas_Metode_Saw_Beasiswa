<?php
include_once ('header.php');
$notif = isset($_GET['notif']) ? $_GET['notif'] : false;
?>

<div class="input-wrapper">
  <div class="container">
    <div class="heading">
      <h1> Input Data Siswa </h1>
      <?php
      if ($notif=="sama") {
        echo "<p class='alert'>NIS sudah digunakan</p>";
      }
      elseif($notif=="gagal"){
       echo "<p class='alert'>Isilah data dengan lengkap !</p>"; 
      }
      ?>
      <form action="input_act.php" method="POST">
        <div class="row">
          <div class="col-25">
            <label>Nama</label>
          </div>
          <div class="col-75">
            <input type="text" name="nama" placeholder="nama lengkap...">
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>NIS</label>
          </div>
          <div class="col-75">
            <input type="text" name="nis" placeholder="nomor induk siswa..">
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label for="country">Kelas</label>
          </div>
          <div class="col-75">
            <select id="kelas" name="kelas">
              <option value="">- silahkan pilih -</option>
              <option value="VII">VII</option>
              <option value="VIII">VIII</option>
              <option value="IX">IX</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>Jenis Beasiswa</label>
          </div>
          <div class="col-75">
            <select id="jb" name="jenis_beasiswa">
              <option value="bkm" selected="select">Beasiswa Kurang Mampu</option>
              <option value="bp" hidden>Beasiswa Prestasi</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>Kartu Asuransi Miskin</label>
          </div>
          <div class="col-75">
            <select id="c1" name="c1">
              <option value="">- silahkan pilih -</option>
              <option value="5">Ada</option>
              <option value="1">Tidak Ada</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>Surat Keterangan Tidak Mampu</label>
          </div>
          <div class="col-75">
            <select id="c2" name="c2">
              <option value="">- silahkan pilih -</option>
              <option value="5">Ada</option>
              <option value="1">Tidak Ada</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>Status Anak dalam Keluarga</label>
          </div>
          <div class="col-75">
            <select id="c3" name="c3">
              <option value="">- silahkan pilih -</option>
              <option value="5">Orang Tua Lengkap</option>
              <option value="3">Yatim / Piatu</option>
              <option value="2">Yatim Piatu</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>Jumlah Penghasilan Orang Tua</label>
          </div>
          <div class="col-75">
            <select id="c4" name="c4">
              <option value="">- silahkan pilih -</option>
              <option value="2"> &lt;1.000.000 </option>
              <option value="3">1.000.000 – 2.000.0000</option>
              <option value="4">2.000.000 – 3.000.000</option>
              <option value="5">&gt;3.000.000</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>Jumlah Tanggungan Orang Tua</label>
          </div>
          <div class="col-75">
            <select id="c5" name="c5">
              <option value="">- silahkan pilih -</option>
              <option value="1">1 Orang</option>
              <option value="2">2 Orang</option>
              <option value="3">3 Orang</option>
              <option value="4">4 Orang</option>
              <option value="5">&gt;=5 Orang</option>
            </select>
          </div>
        </div>
        <div class="row">
          <div class="col-25">
            <label>Rata - Rata Nilai Rapor Semester Terakhir</label>
          </div>
          <div class="col-75">
            <select id="c6" name="c6">
              <option value="">- silahkan pilih -</option>
              <option value="1">51-60</option>
              <option value="2">61-70</option>
              <option value="3">71-80</option>
              <option value="4">81-90</option>
              <option value="5">91-100</option>
            </select>
          </div>
        </div>        
        <div class="row">
          <input type="submit" name="submit" class="sub-data" value="Submit">
        </div>
      </form>

    </div>
  </div>
  
</div>


<?php
include_once ('footer.php');
?>