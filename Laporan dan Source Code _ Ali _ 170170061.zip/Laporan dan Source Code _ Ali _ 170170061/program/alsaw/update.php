<?php

if(isset($_POST['update'])){
	
	include('koneksi.php');
	
	$nama=$_POST['nama'];
	$nis=$_POST['nis'];
	$kelas=$_POST['kelas'];
	$jb=$_POST['jenis_beasiswa'];
	$c1=$_POST['c1'];
	$c2=$_POST['c2'];
	$c3=$_POST['c3'];
	$c4=$_POST['c4'];
	$c5=$_POST['c5'];
	$c6=$_POST['c6'];
	
	$update = mysqli_query($koneksi,"UPDATE matrikulasi SET c1='$c1', c2='$c2',c3='$c3',c4='$c4',c5='$c5',c6='$c6' WHERE nis='$nis'");

	$update2 = mysqli_query($koneksi,"UPDATE siswa SET nama='$nama', kelas='$kelas' WHERE nis='$nis'");
	
	if($update && $update2){
		
		echo "<script>alert('berhasil di edit');</script>";
		header("location: lihat-data.php");
		
	}
	else{
		
		echo "<script>alert('gagal di update');</script>";
		header("location: edit.php");
		
	}

}
?>