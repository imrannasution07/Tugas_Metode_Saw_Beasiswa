<?php
include_once ('header.php');

		//cari min dan max
			$findMax = mysqli_query($koneksi,"SELECT 
				max(c1) as maxC1, 
				max(c2) as maxC2,
				max(c5) as maxC5,
				max(c6) as maxC6
				FROM matrikulasi");
			$max = mysqli_fetch_array($findMax);

			$findMin = mysqli_query($koneksi,"SELECT
				min(c3) as minC3,
				min(c4) as minC4
				FROM matrikulasi");
			$min = mysqli_fetch_array($findMin);			

		//fungsi tampil nama
			function getName($id){

				$koneksi = mysqli_connect("localhost","root","","apk_saw") or die("Koneksi ke database gagal!");
				$q =mysqli_query($koneksi,"SELECT * FROM siswa where nis = '$id'");
				$d = mysqli_fetch_array($q);
				return $d['nama'];
			}

			$ambilData = mysqli_query($koneksi,"SELECT * FROM matrikulasi");

			?>

			<div class="table-wrapper">
				<div class="container">
					<div class="heading">
						<h1> Tabel Matriks Ternormalisasi </h1>
						<table>
							<thead>
								<tr>
									<th>No</th>
									<th>Nama</th>
									<th>C1</th>
									<th>C2</th>
									<th>C3</th>
									<th>C4</th>
									<th>C5</th>
									<th>C6</th>
								</tr>
							</thead>
							<tbody>

			<?php
				$no = 1;
				while ($dt2 = mysqli_fetch_array($ambilData)) {
			?>		


							<tr>
								<td><?php echo $no++; ?></td>
								<td><?php echo getName($dt2['nis']); ?> </td>
								<td><?php echo round($dt2['c1']/$max['maxC1'],3); ?> </td>
								<td><?php echo round($dt2['c2']/$max['maxC2'],3); ?> </td>
								<td><?php echo round($min['minC3']/$dt2['c3'],3); ?> </td>
								<td><?php echo round($min['minC4']/$dt2['c4'],3); ?> </td>
								<td><?php echo round($dt2['c5']/$max['maxC5'],3); ?> </td>
								<td><?php echo round($dt2['c6']/$max['maxC6'],3); ?> </td>
							</tr>

			<?php
			}
			?>				
						</tbody>
						</table>

						</div>
					</div>
				</div>

				<?php
				include_once ('footer.php');
				?>